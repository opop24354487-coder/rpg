This folder contains the cultivation HUD artwork used by the resource pack.
