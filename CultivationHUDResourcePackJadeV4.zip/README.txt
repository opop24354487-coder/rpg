For Minecraft Java Edition / Paper 1.21.
This pack makes only vanilla health, hunger, air, armor, and XP sprites transparent.
The CultivationRPG plugin supplies the replacement RPG HUD via boss bars.
