﻿# CultivationRPG Xianxia Item Pack

This pack maps every CultivationRPG CustomModelData group to a clean 64x64 item icon.
All custom icons use transparent backgrounds and do not contain magic circles or auras.
See the server-side Chinese material map delivered with this build for the player-facing list.
